
<!--
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Edit Monkey - Edit your images online</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
</head>

  <link rel="stylesheet" type="text/css" href="{{ url_for('static', filename='stylesheet.css') }}">


<body>
   
    <div>
    

      <div class="home-container">
        <div class="home-header">
          <header
            data-thq="thq-navbar"
            class="navbarContainer home-navbar-interactive"
          >
            <span class="logo">FlyFast</span>
            <div data-thq="thq-navbar-nav" class="home-desktop-menu">
              <nav class="home-links" style="margin-right: 900px;">
                <span class="home-nav22 bodySmall"><a href="index1.html" style="font-size: 22px;margin-left: 35px;">Home</a></span>
                <!-- <span class="home-nav32 bodySmall"><a href="">Track Order</a></span> -->
                <!-- <span class="home-nav42 bodySmall"><a href="Features.html" style="font-size: 22px; margin-left: 12px;">Features</a></span>
                <span class="home-nav42 bodySmall"><a href="Reviews.html" style="font-size: 22px; margin-left: 12px;">Reviews</a></span> 
                <span class="home-nav52 bodySmall"><a href="contact.html" style="font-size: 22px; margin-left: 12px;">Contact</a></span>
                <span class="home-nav42 bodySmall"><a href="Subscriptions.html" style="font-size: 22px; margin-left: 12px;">Subscriptions</a></span>
              </nav>
              <div class="home-buttons">
                <button class="buttonFilled" onclick="signInWithPopup()" style="cursor: pointer;margin-left: -100px;">Login</button>
              </div>
            </div>
            <div data-thq="thq-burger-menu" class="home-burger-menu">
              <svg viewBox="0 0 1024 1024" class="home-icon socialIcons">
                <path
                  d="M128 554.667h768c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-768c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667zM128 298.667h768c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-768c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667zM128 810.667h768c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-768c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667z"
                ></path>
              </svg>
            </div>
            <div
              data-thq="thq-mobile-menu"
              class="home-mobile-menu1 mobileMenu"
            >
              <!-- <div class="home-nav">
                <div class="home-top">
                  <span class="logo">FlyFast</span>
                  <div data-thq="thq-close-menu" class="home-close-menu">
                    <svg
                      viewBox="0 0 1024 1024"
                      class="home-icon02 socialIcons"
                    >
                      <path
                        d="M810 274l-238 238 238 238-60 60-238-238-238 238-60-60 238-238-238-238 60-60 238 238 238-238z"
                      ></path>
                    </svg>
                  </div>
                </div>
                <nav class="home-links1">
                  <span class="home-nav121 bodySmall"><a href="index.html">Home</a></span>
                  <span class="home-nav321 bodySmall"><a href="">Track Order</a></span>
                  <span class="home-nav421 bodySmall"><a href="Reviews.html">Reviews</a></span>
                  <span class="home-nav521 bodySmall"><a href="contact.html">Contact</a></span>
                </nav>
                <div class="home-buttons1">
                  <button class="buttonFlat">Login</button>
                </div>
              </div> 
              <div>
                <svg
                  viewBox="0 0 950.8571428571428 1024"
                  class="home-icon04 socialIcons"
                >
                  <path
                    d="M925.714 233.143c-25.143 36.571-56.571 69.143-92.571 95.429 0.571 8 0.571 16 0.571 24 0 244-185.714 525.143-525.143 525.143-104.571 0-201.714-30.286-283.429-82.857 14.857 1.714 29.143 2.286 44.571 2.286 86.286 0 165.714-29.143 229.143-78.857-81.143-1.714-149.143-54.857-172.571-128 11.429 1.714 22.857 2.857 34.857 2.857 16.571 0 33.143-2.286 48.571-6.286-84.571-17.143-148-91.429-148-181.143v-2.286c24.571 13.714 53.143 22.286 83.429 23.429-49.714-33.143-82.286-89.714-82.286-153.714 0-34.286 9.143-65.714 25.143-93.143 90.857 112 227.429 185.143 380.571 193.143-2.857-13.714-4.571-28-4.571-42.286 0-101.714 82.286-184.571 184.571-184.571 53.143 0 101.143 22.286 134.857 58.286 41.714-8 81.714-23.429 117.143-44.571-13.714 42.857-42.857 78.857-81.143 101.714 37.143-4 73.143-14.286 106.286-28.571z"
                  ></path></svg>
                <svg
                  viewBox="0 0 877.7142857142857 1024"
                  class="home-icon06 socialIcons"
                >
                  <path
                    d="M585.143 512c0-80.571-65.714-146.286-146.286-146.286s-146.286 65.714-146.286 146.286 65.714 146.286 146.286 146.286 146.286-65.714 146.286-146.286zM664 512c0 124.571-100.571 225.143-225.143 225.143s-225.143-100.571-225.143-225.143 100.571-225.143 225.143-225.143 225.143 100.571 225.143 225.143zM725.714 277.714c0 29.143-23.429 52.571-52.571 52.571s-52.571-23.429-52.571-52.571 23.429-52.571 52.571-52.571 52.571 23.429 52.571 52.571zM438.857 152c-64 0-201.143-5.143-258.857 17.714-20 8-34.857 17.714-50.286 33.143s-25.143 30.286-33.143 50.286c-22.857 57.714-17.714 194.857-17.714 258.857s-5.143 201.143 17.714 258.857c8 20 17.714 34.857 33.143 50.286s30.286 25.143 50.286 33.143c57.714 22.857 194.857 17.714 258.857 17.714s201.143 5.143 258.857-17.714c20-8 34.857-17.714 50.286-33.143s25.143-30.286 33.143-50.286c22.857-57.714 17.714-194.857 17.714-258.857s5.143-201.143-17.714-258.857c-8-20-17.714-34.857-33.143-50.286s-30.286-25.143-50.286-33.143c-57.714-22.857-194.857-17.714-258.857-17.714zM877.714 512c0 60.571 0.571 120.571-2.857 181.143-3.429 70.286-19.429 132.571-70.857 184s-113.714 67.429-184 70.857c-60.571 3.429-120.571 2.857-181.143 2.857s-120.571 0.571-181.143-2.857c-70.286-3.429-132.571-19.429-184-70.857s-67.429-113.714-70.857-184c-3.429-60.571-2.857-120.571-2.857-181.143s-0.571-120.571 2.857-181.143c3.429-70.286 19.429-132.571 70.857-184s113.714-67.429 184-70.857c60.571-3.429 120.571-2.857 181.143-2.857s120.571-0.571 181.143 2.857c70.286 3.429 132.571 19.429 184 70.857s67.429 113.714 70.857 184c3.429 60.571 2.857 120.571 2.857 181.143z"
                  ></path></svg>
                <svg
                  viewBox="0 0 602.2582857142856 1024"
                  class="home-icon08 socialIcons"
                >
                  <path
                    d="M548 6.857v150.857h-89.714c-70.286 0-83.429 33.714-83.429 82.286v108h167.429l-22.286 169.143h-145.143v433.714h-174.857v-433.714h-145.714v-169.143h145.714v-124.571c0-144.571 88.571-223.429 217.714-223.429 61.714 0 114.857 4.571 130.286 6.857z"
                  ></path>
                </svg>
              </div>
            </div>
          </header>
        </div>
<br>
<br>
<br>
<br>
<br>


<br>
<br>
    {% with messages = get_flashed_messages(with_categories=true) %}
    {% if messages %}
     
        {% for category, message in messages %} 
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Success!</strong> {{ message | safe}}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
        {% endfor %}

    {% endif %}
    {% endwith %}


    <div class="container my-4">

        <h1 class="fs-2 text">Edit Monkey - Edit your app online</h1>

        <form action="/edit" method="post" enctype="multipart/form-data">

            <div class="mb-3">
                <label for="formFile" class="form-label">Select an Image to edit</label>
                <input class="form-control" type="file" name="file" id="formFile">
            </div>
            <div class="mb-3">
                <div class="form-floating">
                    <select name="operation" class="form-select" id="floatingSelect"
                        aria-label="Floating label select example">
                        <option selected>Choose an Operation</option>
                        <option value="cpng">Convert to PNG</option>
                        <option value="cgray">Convert to Grayscale</option>
                        <option value="cwebp">Convert to Webp</option>
                        <option value="cjpg">Convert to Jpg</option>
                        <option value="resize_250x250">Resize to 250x250</option>
                        <option value="resize_500x500">Resize to 500x500</option>
                        <option value="resize_1024x1024">Resize to 1024x1024</option>
                        <option value="rotate_90_clockwise">Rotate 90° Clockwise</option>
                        <option value="rotate_90_anticlockwise">Rotate 90° Anticlockwise</option>
                        <option value="rotate_180">Rotate 180°</option>
                        <!-- Basic 
                        <option value="blur">Blur</option>
                        <option value="smooth">Smooth</option>
                        <option value="border">Add Border</option>
                        <option value="flip">Flip</option>
                        <!-- PRO 
                        <option value="pencil">Pencil Sketch</option>
                        <option value="color_sketch">Color Sketch</option>
                        <option value="negative">Negative</option>
                        <option value="crop">Crop</option>
                    </select>
                    <label for="floatingSelect">Select an Editing Operation</label>
                </div>
            </div>

            <!-- Add Text Input Field 
            <div class="mb-3">
                <label for="textToAdd" class="form-label">Add Text</label>
                <input type="text" class="form-control" id="textToAdd" name="textToAdd" placeholder="Enter text to add">
            </div>

            <!-- Submit Button 
    <button type="submit" class="btn btn-success ; buttonFilled" style="color:var(--dl-color-custom-neutral-light);">Submit</button>

        </form>
    </div>
    <script
      data-section-id="navbar"
      src="https://unpkg.com/@teleporthq/teleport-custom-scripts"
    ></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe"
        crossorigin="anonymous"></script>
</body>

</html>
-->

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
        <link rel="stylesheet" href="stylesheet.css">
      <?php

// Configuration
define('UPLOAD_FOLDER', 'uploads');
define('ALLOWED_EXTENSIONS', ['png', 'webp', 'jpg', 'jpeg', 'gif']);

// Function to check if the file extension is allowed
function allowed_file($filename) {
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    return in_array($ext, ALLOWED_EXTENSIONS);
}

// Function to process the image based on the selected operation
function processImage($filename, $operation) {
    $image = imagecreatefromjpeg("uploads/{$filename}");

    switch ($operation) {
      case 'cgray':
        $newFilename = "static/{$filename}";
        imagejpeg($image, $newFilename);
        return $newFilename;
        break;

    case 'cwebp':
        $newFilename = "static/" . pathinfo($filename, PATHINFO_FILENAME) . ".webp";
        imagewebp($image, $newFilename);
        return $newFilename;
        break;

    case 'cjpg':
        $newFilename = "static/" . pathinfo($filename, PATHINFO_FILENAME) . ".jpg";
        imagejpeg($image, $newFilename);
        return $newFilename;
        break;

    case 'cpng':
        $newFilename = "static/" . pathinfo($filename, PATHINFO_FILENAME) . ".png";
        imagepng($image, $newFilename);
        return $newFilename;
        break;

    case 'negative':
        imagefilter($image, IMG_FILTER_NEGATE);
        $newFilename = "static/" . pathinfo($filename, PATHINFO_FILENAME) . "_negative.jpg";
        imagejpeg($image, $newFilename);
        return $newFilename;
        break;

    case 'flip':
        $flipped = imageflip($image, IMG_FLIP_HORIZONTAL);
        $newFilename = "static/" . pathinfo($filename, PATHINFO_FILENAME) . "_flipped.jpg";
        imagejpeg($image, $newFilename);
        return $newFilename;
        break;

    case 'border':
        $borderColor = imagecolorallocate($image, 0, 0, 0);
        $borderWidth = 5;
        $imageWidth = imagesx($image);
        $imageHeight = imagesy($image);
        imagefilledrectangle($image, 0, 0, $imageWidth - 1, $borderWidth - 1, $borderColor);
        imagefilledrectangle($image, 0, 0, $borderWidth - 1, $imageHeight - 1, $borderColor);
        imagefilledrectangle($image, $imageWidth - $borderWidth, 0, $imageWidth - 1, $imageHeight - 1, $borderColor);
        imagefilledrectangle($image, 0, $imageHeight - $borderWidth, $imageWidth - 1, $imageHeight - 1, $borderColor);
        $newFilename = "static/" . pathinfo($filename, PATHINFO_FILENAME) . "_bordered.jpg";
        imagejpeg($image, $newFilename);
        return $newFilename;
        break;

    case 'smooth':
        imagefilter($image, IMG_FILTER_SMOOTH, 10);
        $newFilename = "static/" . pathinfo($filename, PATHINFO_FILENAME) . "_smooth.jpg";
        imagejpeg($image, $newFilename);
        return $newFilename;
        break;

    case 'blur':
        $blurred = imagefilter($image, IMG_FILTER_GAUSSIAN_BLUR);
        $newFilename = "static/" . pathinfo($filename, PATHINFO_FILENAME) . "_blurred.jpg";
        imagejpeg($image, $newFilename);
        return $newFilename;
        break;

    case 'pencil':
        $pencil = imagefilter($image, IMG_FILTER_MEAN_REMOVAL);
        $newFilename = "static/" . pathinfo($filename, PATHINFO_FILENAME) . "_pencil.jpg";
        imagejpeg($image, $newFilename);
        return $newFilename;
        break;

    case 'color_sketch':
        $color_sketch = imagefilter($image, IMG_FILTER_COLORIZE, 0, 0, 255);
        $newFilename = "static/" . pathinfo($filename, PATHINFO_FILENAME) . "_color_sketch.jpg";
        imagejpeg($image, $newFilename);
        return $newFilename;
        break;

    case 'resize_250x250':
        $resized_img = imagescale($image, 250, 250);
        $newFilename = "static/" . pathinfo($filename, PATHINFO_FILENAME) . "_resized_250x250.jpg";
        imagejpeg($resized_img, $newFilename);
        return $newFilename;
        break;

    case 'resize_500x500':
        $resized_img = imagescale($image, 500, 500);
        $newFilename = "static/" . pathinfo($filename, PATHINFO_FILENAME) . "_resized_500x500.jpg";
        imagejpeg($resized_img, $newFilename);
        return $newFilename;
        break;

    case 'resize_1024x1024':
        $resized_img = imagescale($image, 1024, 1024);
        $newFilename = "static/" . pathinfo($filename, PATHINFO_FILENAME) . "_resized_1024x1024.jpg";
        imagejpeg($resized_img, $newFilename);
        return $newFilename;
        break;

    case 'rotate_90_clockwise':
        $rotated_img = imagerotate($image, -90, 0);
        $newFilename = "static/" . pathinfo($filename, PATHINFO_FILENAME) . "_rotated_90_clockwise.jpg";
        imagejpeg($rotated_img, $newFilename);
        return $newFilename;
        break;

    case 'rotate_90_anticlockwise':
        $rotated_img = imagerotate($image, 90, 0);
        $newFilename = "static/" . pathinfo($filename, PATHINFO_FILENAME) . "_rotated_90_anticlockwise.jpg";
        imagejpeg($rotated_img, $newFilename);
        return $newFilename;
        break;

    case 'rotate_180':
        $rotated_img = imagerotate($image, 180, 0);
        $newFilename = "static/" . pathinfo($filename, PATHINFO_FILENAME) . "_rotated_180.jpg";
        imagejpeg($rotated_img, $newFilename);
        return $newFilename;
        break;

    case 'crop':
        $cropped_img = imagecropauto($image);
        $newFilename = "static/" . pathinfo($filename, PATHINFO_FILENAME) . "_cropped.jpg";
        imagejpeg($cropped_img, $newFilename);
        return $newFilename;
        break;

    default:
        return null;
    }
}

// Function to display flash messages
function display_flash_messages() {
    if (isset($_SESSION['flash_messages'])) {
        foreach ($_SESSION['flash_messages'] as $type => $message) {
            echo "<div class='alert alert-$type'>$message</div>";
        }
        unset($_SESSION['flash_messages']); // Clear flash messages after displaying
    }
}
function edit() {
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $operation = $_POST["operation"];

        if (!isset($_FILES["file"]) || $_FILES["file"]["error"] != UPLOAD_ERR_OK) {
            $_SESSION['flash_messages']['error'] = "Error: No file uploaded.";
            return;
        }

        $filename = $_FILES["file"]["name"];
        $tempfile = $_FILES["file"]["tmp_name"];

        if (!allowed_file($filename)) {
            $_SESSION['flash_messages']['error'] = "Error: Invalid file extension.";
            return;
        }

        move_uploaded_file($tempfile, UPLOAD_FOLDER . "/" . $filename);

        $newFilename = processImage($filename, $operation);

        if ($newFilename) {
            return $newFilename; // Return the filename to display the image
        } else {
            $_SESSION['flash_messages']['error'] = "Error: Invalid operation selected.";
        }
    }
}

// Execute the edit function
$result = edit();

?>
</head>
<body>

    <div>

        <div class="home-container">
            <div class="home-header">
            <header
            data-thq="thq-navbar"
            class="navbarContainer home-navbar-interactive"
          >
            <span class="logo">Imaginate</span>
            <div data-thq="thq-navbar-nav" class="home-desktop-menu">
              <nav class="home-links">
                <span class="home-nav22 bodySmall"><a href="index1.php">Home</a></span>
                <span class="home-nav52 bodySmall"><a href="contact.html">Contact</a></span>
                <span class="home-nav42 bodySmall"><a href="Subscriptions.php">Subscriptions</a></span>
              </nav>
              <div class="home-buttons">
                <button class="buttonFilled" onclick="signInWithPopup()">Login</button>
              </div>
            </div>
            <div data-thq="thq-burger-menu" class="home-burger-menu">
              <svg viewBox="0 0 1024 1024" class="home-icon socialIcons">
                <path
                  d="M128 554.667h768c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-768c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667zM128 298.667h768c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-768c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667zM128 810.667h768c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-768c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667z"
                ></path>
              </svg>
            </div>
            <div
              data-thq="thq-mobile-menu"
              class="home-mobile-menu1 mobileMenu"
            >
              <div>
                <svg
                  viewBox="0 0 950.8571428571428 1024"
                  class="home-icon04 socialIcons"
                >
                  <path
                    d="M925.714 233.143c-25.143 36.571-56.571 69.143-92.571 95.429 0.571 8 0.571 16 0.571 24 0 244-185.714 525.143-525.143 525.143-104.571 0-201.714-30.286-283.429-82.857 14.857 1.714 29.143 2.286 44.571 2.286 86.286 0 165.714-29.143 229.143-78.857-81.143-1.714-149.143-54.857-172.571-128 11.429 1.714 22.857 2.857 34.857 2.857 16.571 0 33.143-2.286 48.571-6.286-84.571-17.143-148-91.429-148-181.143v-2.286c24.571 13.714 53.143 22.286 83.429 23.429-49.714-33.143-82.286-89.714-82.286-153.714 0-34.286 9.143-65.714 25.143-93.143 90.857 112 227.429 185.143 380.571 193.143-2.857-13.714-4.571-28-4.571-42.286 0-101.714 82.286-184.571 184.571-184.571 53.143 0 101.143 22.286 134.857 58.286 41.714-8 81.714-23.429 117.143-44.571-13.714 42.857-42.857 78.857-81.143 101.714 37.143-4 73.143-14.286 106.286-28.571z"
                  ></path></svg>
                <svg
                  viewBox="0 0 877.7142857142857 1024"
                  class="home-icon06 socialIcons"
                >
                  <path
                    d="M585.143 512c0-80.571-65.714-146.286-146.286-146.286s-146.286 65.714-146.286 146.286 65.714 146.286 146.286 146.286 146.286-65.714 146.286-146.286zM664 512c0 124.571-100.571 225.143-225.143 225.143s-225.143-100.571-225.143-225.143 100.571-225.143 225.143-225.143 225.143 100.571 225.143 225.143zM725.714 277.714c0 29.143-23.429 52.571-52.571 52.571s-52.571-23.429-52.571-52.571 23.429-52.571 52.571-52.571 52.571 23.429 52.571 52.571zM438.857 152c-64 0-201.143-5.143-258.857 17.714-20 8-34.857 17.714-50.286 33.143s-25.143 30.286-33.143 50.286c-22.857 57.714-17.714 194.857-17.714 258.857s-5.143 201.143 17.714 258.857c8 20 17.714 34.857 33.143 50.286s30.286 25.143 50.286 33.143c57.714 22.857 194.857 17.714 258.857 17.714s201.143 5.143 258.857-17.714c20-8 34.857-17.714 50.286-33.143s25.143-30.286 33.143-50.286c22.857-57.714 17.714-194.857 17.714-258.857s5.143-201.143-17.714-258.857c-8-20-17.714-34.857-33.143-50.286s-30.286-25.143-50.286-33.143c-57.714-22.857-194.857-17.714-258.857-17.714zM877.714 512c0 60.571 0.571 120.571-2.857 181.143-3.429 70.286-19.429 132.571-70.857 184s-113.714 67.429-184 70.857c-60.571 3.429-120.571 2.857-181.143 2.857s-120.571 0.571-181.143-2.857c-70.286-3.429-132.571-19.429-184-70.857s-67.429-113.714-70.857-184c-3.429-60.571-2.857-120.571-2.857-181.143s-0.571-120.571 2.857-181.143c3.429-70.286 19.429-132.571 70.857-184s113.714-67.429 184-70.857c60.571-3.429 120.571-2.857 181.143-2.857s120.571-0.571 181.143 2.857c70.286 3.429 132.571 19.429 184 70.857s67.429 113.714 70.857 184c3.429 60.571 2.857 120.571 2.857 181.143z"
                  ></path></svg>
                <svg
                  viewBox="0 0 602.2582857142856 1024"
                  class="home-icon08 socialIcons"
                >
                  <path
                    d="M548 6.857v150.857h-89.714c-70.286 0-83.429 33.714-83.429 82.286v108h167.429l-22.286 169.143h-145.143v433.714h-174.857v-433.714h-145.714v-169.143h145.714v-124.571c0-144.571 88.571-223.429 217.714-223.429 61.714 0 114.857 4.571 130.286 6.857z"
                  ></path>
                </svg>
              </div>
            </div>
          </header>
            </div>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>


            <br>
            <br>
           
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>Success!</strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        

            <div class="container my-4">

                <h1 class="fs-2 text">Edit your Image</h1>

                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data">

                    <div class="mb-3">
                        <label for="formFile" class="form-label">Select an Image to edit</label>
                        <input class="form-control" type="file" name="file" id="formFile">
                    </div>
                    <div class="mb-3">
                        <div class="form-floating">
                            <select name="operation" class="form-select" id="floatingSelect"
                                aria-label="Floating label select example">
                                <option selected>Choose an Operation</option>
                                <option value="cpng">Convert to PNG</option>
                                <option value="cgray">Convert to Grayscale</option>
                                <option value="cwebp">Convert to Webp</option>
                                <option value="cjpg">Convert to Jpg</option>
                                <option value="resize_250x250">Resize to 250x250</option>
                                <option value="resize_500x500">Resize to 500x500</option>
                                <option value="resize_1024x1024">Resize to 1024x1024</option>
                                <option value="rotate_90_clockwise">Rotate 90° Clockwise</option>
                                <option value="rotate_90_anticlockwise">Rotate 90° Anticlockwise</option>
                                <option value="rotate_180">Rotate 180°</option>
                                <!-- Basic -->
                                <option value="blur">Blur</option>
                                <option value="smooth">Smooth</option>
                                <option value="border">Add Border</option>
                                <option value="flip">Flip</option>
                                <!-- PRO -->
                                <option value="pencil">Pencil Sketch</option>
                                <option value="color_sketch">Color Sketch</option>
                                <option value="negative">Negative</option>
                                <option value="crop">Crop</option>
                            </select>
                            <label for="floatingSelect">Select an Editing Operation</label>
                        </div>
                    </div>

                    

                    <!-- Submit Button -->
                    <button type="submit" class="btn btn-success ; buttonFilled"
                        style="color:var(--dl-color-custom-neutral-light);">Submit</button>

                </form>
                <?php if ($result) : ?>
            <div class="mt-4">
                <h3>Processed Image:</h3>
                <img src="<?php echo $result; ?>" alt="Processed Image" class="img-fluid">
            </div>
        <?php endif; ?>
            </div>
            <script
                data-section-id="navbar"
                src="https://unpkg.com/@teleporthq/teleport-custom-scripts">
            </script>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
                integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe"
                crossorigin="anonymous"></script>
</body>

</html>
