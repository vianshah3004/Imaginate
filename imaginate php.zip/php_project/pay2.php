<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Interface</title>
    <link rel="stylesheet" href="stylesheet.css">
    <style >
        
        /* Basic CSS for styling */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f7f7f7;
        }

        .container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            margin-bottom: 20px; 
            margin-right: 20px;
        }

        label {
            font-weight: bold;
        }

        input[type="text"],
        input[type="number"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        /* input[type="submit"] {
            background-color: #007bff; 
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer; 
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        } */
        
        /* Remove underline from links inside home-buttons */
        .home-buttons a {
            text-decoration: none;
        }
        

    </style>
</head>

<body> 
    

    <div class="container">
        <div class="home-buttons">
            <button class="buttonFilled" style="cursor: pointer;margin-left: 5px;"><a href="Subscriptions.php">Back</a></button>
        </div>
        <h2 style="margin-left: 210px;">Payment Form</h2>
        <form method="POST"<?php $_SERVER["PHP_SELF"];?> onsubmit="return validateForm()">
            <div class="form-group">
                <label for="card_number">Card Number</label>
                <input type="text" id="card_number" name="card_number" placeholder="Enter your card number"
                    pattern="[0-9]{16}" required>
            </div>
            <div class="form-group">
                <label for="expiry_date">Expiry Date</label>
                <input type="text" id="expiry_date" name="expiry_date" placeholder="MM/YY"
                    pattern="(0[1-9]|1[0-2])\/([0-9]{2})" required>
            </div>
            <div class="form-group">
                <label for="cvv">CVV</label>
                <input type="password" id="cvv" name="cvv" placeholder="CVV" pattern="[0-9]{3}" required>
            </div>
            <div class="form-group">
                <label for="name">Cardholder Name</label>
                <input type="text" id="name" name="name" placeholder="Enter cardholder name" required>
            </div>
            <div class="form-group">
                <label for="amount">Amount</label>
                <input type="number" id="amount" name="amount" placeholder="Enter amount" value="249" readonly required>
            </div>            
            <!-- <div class="form-group" >
                <input type="submit" value="Pay Now">
            </div> -->
            <!-- <div class="container"> -->
            <div class="home-buttons">
                <button class="buttonFilled" style="margin-left: 250px;"><a href="index2.php">Submit</a>
            </div>
        </form>
        
    </div>

    <script>
        function validateForm() {
            var cardNumber = document.getElementById('card_number').value;
            var expiryDate = document.getElementById('expiry_date').value;
            var cvv = document.getElementById('cvv').value;

            // Regular expressions for validation
            var cardNumberRegex = /^[0-9]{16}$/;
            var expiryDateRegex = /^(0[1-9]|1[0-2])\/([0-9]{2})$/;
            var cvvRegex = /^[0-9]{3}$/;

            // Validate card number
            if (!cardNumberRegex.test(cardNumber)) {
                alert('Please enter a valid 16-digit card number');
                return false;
            }

            // Validate expiry date
            if (!expiryDateRegex.test(expiryDate)) {
                alert('Please enter a valid expiry date in MM/YY format');
                return false;
            }

            // Validate CVV
            if (!cvvRegex.test(cvv)) {
                alert('Please enter a valid 3-digit CVV');
                return false;
            }

            // Alert on successful submission
            alert('Plan purchased successfully');
            setTimeout(function() {
                window.location.href = 'index.html';
            }, 100); // 100 milliseconds delay
            return true; 
        }
    </script>

</body>
<?php
        // Database connection configuration
        $servername = "localhost"; // Change this if your database is hosted elsewhere
        $username = "root"; // Change this to your database username
        $password = ""; // Change this to your database password
        $dbname = "tm2"; // Change this if your database name is different

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Process payment logic here
            $card_number = $_POST['card_number'];
            $expiry_date = $_POST['expiry_date'];
            $cvv = $_POST['cvv'];
            $name = $_POST['name'];
            $amount = $_POST['amount'];

            // Prepare SQL statement to insert data into the payment table
            $sql = "INSERT INTO `payment` (`card_number`, `expiry_date`,`cardholder_name`, `amount`) VALUES ('$card_number', '$expiry_date','$name', '$amount')";
            mysqli_query($conn,$sql);
               
        }

        // Close the database connection
        $conn->close();
        ?>
</html>
